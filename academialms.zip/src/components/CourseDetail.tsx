import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { PlayCircle, Clock, Globe, Shield, Star, CheckCircle, ChevronRight, User, BookOpen } from 'lucide-react';
import { Course, Lesson } from '../types';
import { courseService } from '../services/courseService';
import { useAuth } from '../contexts/AuthContext';

const CourseDetail = () => {
  const { id } = useParams<{ id: string }>();
  const [course, setCourse] = useState<Course | null>(null);
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (id) {
      const fetchData = async () => {
        const c = await courseService.getCourseById(id);
        if (c) {
          setCourse(c);
          const l = await courseService.getLessons(id);
          setLessons(l);
        }
        setLoading(false);
      };
      fetchData();
    }
  }, [id]);

  const handleEnroll = async () => {
    if (!user) {
      alert("Please sign in to enroll");
      return;
    }
    if (course) {
      await courseService.enrollInCourse(user.uid, course.id);
      navigate(`/learning/${course.id}`);
    }
  };

  if (loading) return <div className="py-64 text-center">Loading course...</div>;
  if (!course) return <div className="py-64 text-center">Course not found.</div>;

return (
    <div className="bg-[#0F1115] min-h-screen">
      {/* Header / Hero */}
      <div className="bg-[#1A1D23] text-[#E2E8F0] pt-40 pb-20 px-6 border-b border-[#2D333B]">
        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row gap-16">
          <div className="flex-grow max-w-3xl">
            <nav className="flex items-center gap-3 text-[10px] font-bold uppercase tracking-[3px] text-[#64748B] mb-8">
              <span>Catalog</span> <ChevronRight size={12} /> <span className="text-indigo-400">{course.category}</span>
            </nav>
            <h1 className="text-5xl md:text-6xl font-black mb-8 leading-none tracking-tighter text-white">{course.title}</h1>
            <p className="text-xl text-[#94A3B8] mb-10 leading-relaxed font-medium">{course.description}</p>
            
            <div className="flex flex-wrap gap-8 text-xs mb-10">
              <div className="flex items-center gap-2">
                <Star className="text-amber-500 fill-current w-5 h-5" />
                <span className="font-bold text-white text-lg">4.8</span>
                <span className="text-[#64748B] font-bold tracking-widest uppercase ml-2">(1,240 Ratings)</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-indigo-500/10 flex items-center justify-center text-indigo-400 border border-indigo-500/20">
                   <User size={16} />
                </div>
                <span className="text-[#94A3B8] font-bold">Instructor: <span className="text-white underline decoration-indigo-500/50">{course.instructorName}</span></span>
              </div>
              <div className="flex items-center gap-2 text-[#94A3B8] font-bold lowercase tracking-widest bg-[#0F1115] px-3 py-1 rounded-full border border-[#2D333B]">
                <Globe size={14} /> <span>English (Secure Stream)</span>
              </div>
            </div>
          </div>
          
          {/* Purchase Card */}
          <div className="lg:w-96 flex-shrink-0">
            <div className="sticky top-40 bg-[#1A1D23] rounded-3xl shadow-2xl overflow-hidden border border-[#2D333B] text-[#E2E8F0]">
              <div className="relative group cursor-pointer aspect-video bg-black overflow-hidden">
                <img src={course.thumbnail} alt={course.title} className="w-full h-full object-cover opacity-60 group-hover:opacity-40 transition-all duration-700 group-hover:scale-110" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-16 h-16 bg-indigo-600 rounded-full flex items-center justify-center shadow-2xl shadow-indigo-600/40 group-hover:scale-110 transition-transform">
                    <PlayCircle className="w-8 h-8 text-white fill-current" />
                  </div>
                </div>
                <div className="absolute bottom-4 left-0 right-0 text-center text-white text-[10px] font-black uppercase tracking-[3px] opacity-70">Infrastructure Preview</div>
              </div>
              
              <div className="p-8">
                <div className="flex items-baseline gap-3 mb-8">
                  <span className="text-5xl font-black text-white">${course.price}</span>
                  <span className="text-[#64748B] line-through text-sm">$89.99</span>
                  <span className="px-2 py-0.5 bg-rose-500/10 text-rose-500 text-[10px] font-bold rounded uppercase tracking-widest">Limited Offer</span>
                </div>
                
                <div className="flex flex-col gap-4 mb-10">
                  <button onClick={handleEnroll} className="w-full py-5 bg-indigo-600 hover:bg-indigo-500 text-white font-black rounded-2xl transition-all shadow-xl shadow-indigo-600/30 uppercase tracking-widest text-sm">
                    Initialize Enrollment
                  </button>
                  <button className="w-full py-5 border border-[#2D333B] hover:bg-[#2D333B] text-white font-bold rounded-2xl transition-all uppercase tracking-widest text-sm">
                    Add to Favorites
                  </button>
                </div>
                
                <div>
                  <h4 className="font-bold mb-6 text-[10px] uppercase tracking-[4px] text-[#64748B]">Stream Manifest:</h4>
                  <ul className="space-y-4 text-xs font-bold text-[#94A3B8]">
                    <li className="flex items-center gap-4"><PlayCircle size={16} className="text-indigo-400" /> 12 Hours On-Demand Stream</li>
                    <li className="flex items-center gap-4"><BookOpen size={16} className="text-indigo-400" /> 24 Encrypted Workbooks</li>
                    <li className="flex items-center gap-4"><Shield size={16} className="text-indigo-400" /> Full Infrastructure Access</li>
                    <li className="flex items-center gap-4"><CheckCircle size={16} className="text-indigo-400" /> PGP Signed Certificate</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-24 grid grid-cols-1 lg:grid-cols-3 gap-20">
        <div className="lg:col-span-2">
          <section className="mb-20 bg-[#1A1D23] p-10 rounded-3xl border border-[#2D333B] shadow-2xl">
            <h2 className="text-3xl font-black mb-8 text-white tracking-tight">Terminal Objectives</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[
                'Build full-stack applications with modern tech',
                'Master complex logic and database architecture',
                'Deploy and scale on professional platforms',
                'Work with authentication and security best practices'
              ].map((item, i) => (
                <div key={i} className="flex gap-4 text-sm font-medium text-[#94A3B8] leading-relaxed">
                  <CheckCircle size={20} className="text-emerald-500 flex-shrink-0" />
                  <span>{item}</span>
                </div>
              ))}
            </div>
          </section>

          <section className="mb-20">
            <h2 className="text-3xl font-black mb-8 text-white tracking-tight">Curriculum Structure</h2>
            <div className="border border-[#2D333B] rounded-3xl overflow-hidden shadow-2xl">
               {lessons.length > 0 ? lessons.map((lesson, idx) => (
                 <div key={lesson.id} className="flex items-center justify-between p-6 border-b border-[#2D333B] hover:bg-[#23272F]/50 transition-colors group cursor-pointer">
                   <div className="flex items-center gap-6">
                     <span className="text-[#64748B] font-mono text-xs w-6">{idx + 1}</span>
                     <div className="w-10 h-10 rounded-xl bg-[#0F1115] border border-[#2D333B] flex items-center justify-center text-[#64748B] group-hover:text-indigo-400 group-hover:border-indigo-500/30 transition-all">
                        <PlayCircle size={20} />
                     </div>
                     <span className="font-bold text-[#E2E8F0] tracking-tight">{lesson.title}</span>
                   </div>
                   <span className="text-[10px] font-mono text-[#64748B] bg-[#0F1115] px-2 py-1 rounded border border-[#2D333B]">{lesson.duration || '08:24'}</span>
                 </div>
               )) : (
                 <div className="p-20 text-center text-[#64748B] bg-[#1A1D23] font-mono uppercase tracking-[4px] text-xs">No streams initialized.</div>
               )}
            </div>
          </section>

          <section>
            <h2 className="text-3xl font-black mb-8 text-white tracking-tight">Course Description</h2>
            <div className="prose prose-invert prose-indigo max-w-none text-[#94A3B8] leading-relaxed font-medium">
              {course.description}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

export default CourseDetail;
