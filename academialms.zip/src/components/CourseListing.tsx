import React, { useState, useEffect } from 'react';
import { Search, Filter, Grid, List as ListIcon, ChevronDown, BookOpen } from 'lucide-react';
import { motion } from 'motion/react';
import CourseCard from './CourseCard';
import { Course } from '../types';
import { courseService } from '../services/courseService';

const CourseListing = () => {
  const [courses, setCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [category, setCategory] = useState('All');

  useEffect(() => {
    const fetchCourses = async () => {
      const data = await courseService.getAllCourses();
      setCourses(data);
      setLoading(false);
    };
    fetchCourses();
  }, []);

  const filteredCourses = courses.filter(c => {
    const matchesSearch = c.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = category === 'All' || c.category === category;
    return matchesSearch && matchesCategory;
  });

  const categories = ['All', 'Web Development', 'Design', 'Business', 'Marketing', 'Data Science', 'Backend', 'Infrastructure', 'Frontend'];

  return (
    <div className="bg-[#0F1115] min-h-screen pt-32 pb-24">
      <div className="max-w-7xl mx-auto px-6">
        <header className="mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-500/10 border border-indigo-500/20 rounded-full text-indigo-400 text-[10px] font-bold uppercase tracking-[3px] mb-6">
            <Search size={12} /> Resource Discovery
          </div>
          <h1 className="text-5xl font-black mb-4 text-white tracking-tighter">Enterprise Catalog</h1>
          <p className="text-[#94A3B8] max-w-2xl font-medium">Explore professional certification paths and technical deep-dives for modern cloud architecture.</p>
        </header>

        <div className="flex flex-col md:flex-row gap-6 mb-16">
          {/* Search */}
          <div className="relative flex-grow">
            <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-[#64748B] w-5 h-5" />
            <input 
              type="text" 
              placeholder="Query database for courses, instructors or tags..." 
              className="w-full pl-16 pr-6 py-5 bg-[#1A1D23] border border-[#2D333B] rounded-2xl shadow-2xl focus:ring-2 focus:ring-indigo-500/50 outline-none transition-all text-[#E2E8F0] font-medium placeholder-[#4A5565]"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          {/* Filters */}
          <div className="flex flex-wrap gap-4">
             <div className="relative inline-block">
                <select 
                  className="appearance-none pl-8 pr-14 py-5 bg-[#1A1D23] border border-[#2D333B] rounded-2xl shadow-2xl outline-none cursor-pointer font-bold text-xs uppercase tracking-widest text-[#94A3B8] focus:ring-2 focus:ring-indigo-500/50 transition-all hover:bg-[#2D333B]"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                >
                  {categories.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
                <ChevronDown className="absolute right-6 top-1/2 -translate-y-1/2 text-[#64748B] w-4 h-4 pointer-events-none" />
             </div>
             
             <button className="p-5 bg-[#1A1D23] border border-[#2D333B] rounded-2xl shadow-2xl hover:bg-[#2D333B] text-[#94A3B8] transition-all">
               <Filter className="w-5 h-5" />
             </button>
             
             <div className="flex bg-[#1A1D23] border border-[#2D333B] rounded-2xl shadow-2xl p-1.5">
               <button className="p-3 bg-indigo-600 rounded-xl text-white shadow-lg shadow-indigo-600/30"><Grid size={18} /></button>
               <button className="p-3 text-[#64748B] hover:text-[#94A3B8] transition-colors"><ListIcon size={18} /></button>
             </div>
          </div>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3, 4, 5, 6].map(i => (
              <div key={i} className="h-[450px] bg-[#1A1D23] rounded-3xl animate-pulse border border-[#2D333B]"></div>
            ))}
          </div>
        ) : filteredCourses.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredCourses.map(course => (
              <CourseCard key={course.id} course={course} />
            ))}
          </div>
        ) : (
          <div className="py-40 text-center bg-[#1A1D23] rounded-3xl border border-[#2D333B] border-dashed">
            <div className="text-[#2D333B] mb-6 flex justify-center"><BookOpen size={64} /></div>
            <h3 className="text-2xl font-bold mb-2 text-white">No matches found</h3>
            <p className="text-[#64748B] font-mono text-sm uppercase tracking-widest">Query returned 0 results. Try broadening your parameters.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default CourseListing;
