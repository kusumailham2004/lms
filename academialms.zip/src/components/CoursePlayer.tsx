import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { PlayCircle, CheckCircle, ChevronLeft, Menu, ChevronRight, FileText, Video, HelpCircle, Clock } from 'lucide-react';
import { Course, Lesson } from '../types';
import { courseService } from '../services/courseService';

const CoursePlayer = () => {
  const { id } = useParams<{ id: string }>();
  const [course, setCourse] = useState<Course | null>(null);
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [currentLesson, setCurrentLesson] = useState<Lesson | null>(null);
  const [loading, setLoading] = useState(true);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  useEffect(() => {
    if (id) {
      const fetchData = async () => {
        const c = await courseService.getCourseById(id);
        const l = await courseService.getLessons(id);
        setCourse(c);
        setLessons(l);
        if (l.length > 0) setCurrentLesson(l[0]);
        setLoading(false);
      };
      fetchData();
    }
  }, [id]);

  if (loading) return <div className="h-screen flex items-center justify-center">Loading learning environment...</div>;
  if (!course) return <div className="h-screen flex items-center justify-center">Course not found.</div>;

  return (
    <div className="h-screen bg-[#0F1115] flex flex-col pt-20">
      {/* Top Header */}
      <div className="bg-[#1A1D23] text-[#E2E8F0] py-4 px-8 flex justify-between items-center z-40 border-b border-[#2D333B] shadow-2xl">
        <div className="flex items-center gap-6">
          <Link to="/dashboard" className="p-2.5 bg-[#0F1115] hover:bg-[#2D333B] rounded-xl border border-[#2D333B] transition-all text-[#64748B] hover:text-white">
            <ChevronLeft size={18} />
          </Link>
          <div className="h-8 w-[1px] bg-[#2D333B]"></div>
          <div>
            <div className="text-[10px] text-indigo-400 font-bold uppercase tracking-[3px] mb-1 leading-none">Stream Active</div>
            <h1 className="font-black text-sm md:text-lg tracking-tighter truncate max-w-xs md:max-w-xl text-white">{course.title}</h1>
          </div>
        </div>
        <div className="flex items-center gap-8">
           <div className="hidden lg:flex items-center gap-4">
             <div className="text-right">
                <div className="text-[10px] font-black text-[#64748B] uppercase tracking-[3px]">Synchronization</div>
                <div className="text-xs font-bold text-emerald-400">25% Optimized</div>
             </div>
             <div className="w-32 bg-[#0F1115] h-2 rounded-full overflow-hidden border border-[#2D333B]">
               <div className="bg-emerald-500 h-full w-[25%] shadow-[0_0_8px_rgba(16,185,129,0.4)]"></div>
             </div>
           </div>
           <button className="px-6 py-2.5 bg-indigo-600 rounded-xl text-[10px] font-black uppercase tracking-widest text-white hover:bg-indigo-500 shadow-xl shadow-indigo-600/30 transition-all">Export Certificate</button>
        </div>
      </div>

      <div className="flex flex-grow overflow-hidden">
        {/* Main Content Area */}
        <div className="flex-grow flex flex-col">
          <div className="flex-grow bg-black flex items-center justify-center overflow-hidden relative group">
            {currentLesson?.videoUrl ? (
              <div className="w-full h-full"> 
                <iframe 
                  className="w-full h-full"
                  src={`https://www.youtube.com/embed/${currentLesson.videoUrl}?autoplay=0`}
                  title="Stream Player" 
                  frameBorder="0" 
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                  allowFullScreen
                ></iframe>
              </div>
            ) : (
              <div className="text-center p-12 max-w-lg border border-[#2D333B] bg-[#1A1D23] rounded-3xl shadow-2xl">
                 <Video size={64} className="text-[#2D333B] mx-auto mb-6" />
                 <h2 className="text-white text-3xl font-black mb-3 tracking-tighter">Null Stream</h2>
                 <p className="text-[#64748B] font-medium leading-relaxed">No video data localized for this module. Please consult the documentation below for technical specifications.</p>
              </div>
            )}
          </div>

          <div className="bg-[#1A1D23] overflow-y-auto p-12 h-[45%] border-t border-[#2D333B] shadow-[0_-20px_50px_rgba(0,0,0,0.5)]">
            <div className="max-w-5xl mx-auto">
               <header className="mb-12 flex flex-col md:flex-row justify-between items-start gap-8">
                 <div>
                   <div className="text-[10px] font-black text-indigo-400 uppercase tracking-[4px] mb-4">Module {currentLesson?.order}</div>
                   <h2 className="text-4xl font-black mb-4 text-white tracking-tighter">{currentLesson?.title}</h2>
                   <div className="flex items-center gap-4 text-[#64748B] font-mono text-xs uppercase tracking-widest bg-[#0F1115] inline-flex px-4 py-2 rounded-xl border border-[#2D333B]">
                      <Clock size={14} /> <span>Estimated Read: {currentLesson?.duration || '12 mins'}</span>
                   </div>
                 </div>
                 <button className="flex items-center gap-3 px-8 py-4 border-2 border-emerald-500/30 text-emerald-400 font-black rounded-2xl hover:bg-emerald-500/10 transition-all uppercase tracking-widest text-xs">
                   <CheckCircle size={18} /> Finalize Module
                 </button>
               </header>
               <div className="prose prose-invert prose-indigo max-w-none text-[#94A3B8] leading-relaxed font-medium text-lg pb-32">
                 {currentLesson?.content || 'No content serialized for this sector.'}
                 <hr className="my-16 border-[#2D333B]" />
                 <h4 className="text-white font-black text-xs uppercase tracking-[4px] mb-8">System Assets & Manifests</h4>
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="flex items-center justify-between p-6 bg-[#0F1115] rounded-2xl border border-[#2D333B] group cursor-pointer hover:border-indigo-500/50 transition-all shadow-xl">
                      <div className="flex items-center gap-6">
                        <div className="w-12 h-12 rounded-xl bg-indigo-500/10 flex items-center justify-center text-indigo-400 border border-indigo-500/20">
                           <FileText size={20} />
                        </div>
                        <div>
                           <span className="block font-bold text-white text-sm">Course_Architecture.pdf</span>
                           <span className="text-[10px] text-[#64748B] uppercase font-bold tracking-widest mt-1 block">4.2 MB • PDF Document</span>
                        </div>
                      </div>
                      <ChevronRight size={18} className="text-[#2D333B] group-hover:text-indigo-400 transition-colors" />
                    </div>
                 </div>
               </div>
            </div>
          </div>
        </div>

        {/* Sidebar Navigation */}
        <aside className={`${isSidebarOpen ? 'w-96' : 'w-0'} flex-shrink-0 bg-[#0F1115] border-l border-[#2D333B] transition-all duration-500 relative flex flex-col shadow-[-20px_0_50px_rgba(0,0,0,0.5)]`}>
          <button 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="absolute left-[-48px] top-6 w-12 h-12 bg-[#0F1115] border border-[#2D333B] rounded-l-2xl flex items-center justify-center shadow-2xl transition-colors hover:text-indigo-400 group"
          >
            <Menu size={20} className="text-[#64748B] group-hover:rotate-90 transition-transform" />
          </button>

          <header className="p-8 border-b border-[#2D333B] bg-[#1A1D23]/50">
            <h3 className="font-black text-[10px] uppercase tracking-[4px] text-[#64748B]">Stream Topology</h3>
          </header>
          
          <div className="flex-grow overflow-y-auto custom-scrollbar">
            {lessons.map((lesson, idx) => (
              <button 
                key={lesson.id}
                onClick={() => setCurrentLesson(lesson)}
                className={`w-full text-left p-8 border-b border-[#2D333B] flex gap-6 hover:bg-[#1A1D23] transition-all group relative ${currentLesson?.id === lesson.id ? 'bg-[#1A1D23]' : ''}`}
              >
                {currentLesson?.id === lesson.id && (
                   <div className="absolute left-0 top-0 bottom-0 w-1 bg-indigo-500 shadow-[0_0_10px_rgba(99,102,241,0.5)]"></div>
                )}
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 mt-0.5 font-mono text-xs border ${currentLesson?.id === lesson.id ? 'bg-indigo-600 border-indigo-500 text-white shadow-lg shadow-indigo-600/30' : 'bg-[#0F1115] border-[#2D333B] text-[#64748B]'}`}>
                  {String(idx + 1).padStart(2, '0')}
                </div>
                <div>
                  <h4 className={`text-md font-bold mb-2 leading-tight tracking-tight ${currentLesson?.id === lesson.id ? 'text-white' : 'text-[#64748B] group-hover:text-[#94A3B8]'}`}>{lesson.title}</h4>
                  <div className="flex items-center gap-4 text-[10px] text-[#4A5565] font-black uppercase tracking-widest">
                    <span className="flex items-center gap-2"> <Video size={12} /> Video</span>
                    <span className="w-1 h-1 rounded-full bg-[#2D333B]"></span>
                    <span>{lesson.duration || '08:24'}</span>
                  </div>
                </div>
              </button>
            ))}
          </div>

          <footer className="p-8 bg-[#1A1D23]/30 border-t border-[#2D333B]">
            <button className="w-full py-4 bg-[#0F1115] border border-[#2D333B] rounded-2xl text-[10px] font-black uppercase tracking-[3px] text-[#64748B] hover:text-white hover:border-indigo-500/50 transition-all flex items-center justify-center gap-3">
              <HelpCircle size={14} /> Open Support Ticket
            </button>
          </footer>
        </aside>
      </div>
    </div>
  );
};

export default CoursePlayer;
