import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { Clock, BookOpen, Star, User } from 'lucide-react';
import { Course } from '../types';

interface CourseCardProps {
  course: Course;
}

const CourseCard: React.FC<CourseCardProps> = ({ course }) => {
  return (
    <motion.div 
      whileHover={{ y: -5 }}
      className="bg-[#1A1D23] border border-[#2D333B] rounded-3xl overflow-hidden shadow-2xl transition-all h-full flex flex-col group"
    >
      <Link to={`/course/${course.id}`} className="block relative h-52 overflow-hidden">
        <img 
          src={course.thumbnail || 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=2070&auto=format&fit=crop'} 
          alt={course.title} 
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 opacity-70 group-hover:opacity-100" 
        />
        <div className="absolute top-4 left-4">
          <span className="px-3 py-1 bg-black/40 backdrop-blur-md border border-white/10 text-white text-[10px] font-bold rounded-full uppercase tracking-widest">
            {course.category}
          </span>
        </div>
      </Link>
      
      <div className="p-8 flex flex-col flex-grow">
        <div className="flex items-center gap-1 text-amber-500 mb-4">
          <Star className="w-3 h-3 fill-current" />
          <Star className="w-3 h-3 fill-current" />
          <Star className="w-3 h-3 fill-current" />
          <Star className="w-3 h-3 fill-current" />
          <Star className="w-3 h-3 text-[#2D333B]" />
          <span className="text-[10px] text-[#64748B] font-bold ml-2 tracking-widest uppercase">4.2 Rating</span>
        </div>
        
        <Link to={`/course/${course.id}`}>
          <h3 className="text-xl font-bold mb-3 line-clamp-2 text-white group-hover:text-indigo-400 transition-colors tracking-tight">
            {course.title}
          </h3>
        </Link>
        
        <p className="text-[#94A3B8] text-sm mb-8 line-clamp-2 flex-grow leading-relaxed">
          {course.description}
        </p>
        
        <div className="flex items-center justify-between pt-6 border-t border-[#2D333B] mt-auto">
          <div className="flex items-center gap-3">
             <div className="w-8 h-8 rounded-lg bg-indigo-500/10 flex items-center justify-center text-indigo-400 border border-indigo-500/20">
               <User className="w-4 h-4" />
             </div>
             <span className="text-xs font-bold text-[#94A3B8]">{course.instructorName}</span>
          </div>
          <div className="text-lg font-black text-white">
            {course.price === 0 ? 'Free' : `$${course.price.toFixed(2)}`}
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default CourseCard;
