import React, { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { LogIn, GraduationCap, Briefcase, ChevronRight, ShieldCheck, Sparkles } from 'lucide-react';
import { loginWithGoogle } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';
import { UserRole } from '../types';

const LoginPage = () => {
  const [searchParams] = useSearchParams();
  const [activeTab, setActiveTab] = useState<'student' | 'professional'>(
    searchParams.get('type') === 'instructor' ? 'professional' : 'student'
  );
  const { setRole } = useAuth();
  const navigate = useNavigate();
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const user = await loginWithGoogle();
      if (user) {
        // If they logged in through the professional tab, ensure they are set as instructor
        if (activeTab === 'professional') {
          await setRole(UserRole.INSTRUCTOR);
        }
        navigate('/dashboard');
      }
    } catch (err) {
      setError('System authentication failed. Please retry.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0F1115] pt-32 pb-24 px-6 flex items-center justify-center relative overflow-hidden">
      {/* Background decor */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-indigo-600/10 blur-[120px] rounded-full pointer-events-none"></div>
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-rose-500/5 blur-[120px] rounded-full pointer-events-none"></div>

      <div className="max-w-md w-full relative z-10">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-500/10 border border-indigo-500/20 rounded-full text-indigo-400 text-[10px] font-bold uppercase tracking-[3px] mb-6">
            Access Control Terminal
          </div>
          <h1 className="text-4xl font-black text-white tracking-tighter mb-4">
            Initialize <span className="text-indigo-500">Session</span>
          </h1>
          <p className="text-[#64748B] font-medium">Select your clearance level to continue to the platform.</p>
        </div>

        <div className="bg-[#1A1D23] border border-[#2D333B] rounded-[32px] p-2 mb-8 shadow-2xl flex relative overflow-hidden">
           <div 
             className={`absolute top-2 bottom-2 w-[calc(50%-8px)] bg-indigo-600 rounded-[24px] transition-all duration-500 ease-[cubic-bezier(0.23,1,0.32,1)] ${activeTab === 'professional' ? 'translate-x-[calc(100%+8px)] bg-indigo-600' : 'translate-x-0'}`}
           ></div>
           
           <button 
             onClick={() => setActiveTab('student')}
             className={`flex-1 flex items-center justify-center gap-3 py-4 text-xs font-black uppercase tracking-widest relative z-10 transition-colors ${activeTab === 'student' ? 'text-white' : 'text-[#64748B]'}`}
           >
             <GraduationCap size={16} /> Student
           </button>
           <button 
             onClick={() => setActiveTab('professional')}
             className={`flex-1 flex items-center justify-center gap-3 py-4 text-xs font-black uppercase tracking-widest relative z-10 transition-colors ${activeTab === 'professional' ? 'text-white' : 'text-[#64748B]'}`}
           >
             <Briefcase size={16} /> Professional
           </button>
        </div>

        <div className="bg-[#1A1D23] border border-[#2D333B] rounded-[32px] p-10 shadow-2xl relative overflow-hidden group">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
            >
              {activeTab === 'student' ? (
                <div className="mb-10">
                   <div className="w-16 h-16 bg-indigo-500/10 border border-indigo-500/20 rounded-2xl flex items-center justify-center text-indigo-400 mb-8 mx-auto shadow-inner group-hover:scale-110 transition-transform">
                      <GraduationCap size={32} />
                   </div>
                   <h3 className="text-xl font-bold text-white text-center mb-2 tracking-tight">Student Access</h3>
                   <p className="text-[#64748B] text-center text-sm leading-relaxed">Access your learning paths, synchronize progress, and earn certifications.</p>
                </div>
              ) : (
                <div className="mb-10">
                   <div className="w-16 h-16 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl flex items-center justify-center text-emerald-400 mb-8 mx-auto shadow-inner group-hover:scale-110 transition-transform">
                      <ShieldCheck size={32} />
                   </div>
                   <h3 className="text-xl font-bold text-white text-center mb-2 tracking-tight">Root Console</h3>
                   <p className="text-[#64748B] text-center text-sm leading-relaxed">Administrative & instructor portal. Manage resources, monitor streams, and configure system architecture.</p>
                </div>
              )}
            </motion.div>
          </AnimatePresence>

          {error && (
            <div className="mb-8 p-4 bg-rose-500/10 border border-rose-500/20 rounded-2xl text-rose-500 text-xs font-bold uppercase tracking-widest text-center animate-shake">
              {error}
            </div>
          )}

          <button 
            onClick={handleLogin}
            disabled={isLoading}
            className={`w-full py-5 rounded-2xl font-black uppercase tracking-[4px] text-xs flex items-center justify-center gap-4 transition-all shadow-2xl ${activeTab === 'professional' ? 'bg-white text-black hover:bg-gray-200' : 'bg-indigo-600 text-white hover:bg-indigo-500 shadow-indigo-600/30'}`}
          >
            {isLoading ? (
               <div className="w-5 h-5 border-2 border-current border-t-transparent rounded-full animate-spin"></div>
            ) : (
              <>
                <LogIn size={18} />
                {activeTab === 'student' ? 'Authenticate Student' : 'Initialize Root Access'}
              </>
            )}
          </button>

          <div className="mt-10 pt-8 border-t border-[#2D333B] flex items-center justify-between text-[10px] font-black uppercase tracking-widest text-[#4A5565]">
             <div className="flex items-center gap-2">
                <Sparkles size={12} className="text-amber-500" />
                SSO Enabled
             </div>
             <div>v4.0.0 Stable</div>
          </div>
        </div>

        <p className="mt-12 text-center text-sm text-[#64748B] font-medium leading-relaxed px-8">
           Protected by Lumina Sentinel. High-tier encryption active for all on-premise authentication requests.
        </p>
      </div>
    </div>
  );
};

export default LoginPage;
