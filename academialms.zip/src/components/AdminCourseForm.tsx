import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import { 
  ChevronLeft, 
  Save, 
  Image as ImageIcon, 
  Type, 
  FileText, 
  Tag, 
  DollarSign, 
  User as UserIcon,
  Plus,
  Trash2,
  List
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { courseService } from '../services/courseService';
import { Course, UserRole } from '../types';

const AdminCourseForm = () => {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    thumbnail: '',
    category: '',
    price: 0,
    published: false,
    instructorName: user?.displayName || ''
  });

  if (!user || profile?.role !== UserRole.INSTRUCTOR) {
    return (
      <div className="min-h-screen bg-[#0F1115] flex items-center justify-center p-6">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-white mb-4">Access Denied</h2>
          <p className="text-[#64748B] mb-8">You do not have the required clearance to access this terminal.</p>
          <button 
            onClick={() => navigate('/dashboard')}
            className="px-8 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-500 transition-all"
          >
            Return to Dashboard
          </button>
        </div>
      </div>
    );
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'number' ? parseFloat(value) : value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title || !formData.description || !formData.thumbnail || !formData.category) {
      setError('All synchronization parameters must be defined.');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const courseData: Partial<Course> = {
        title: formData.title,
        description: formData.description,
        thumbnail: formData.thumbnail,
        category: formData.category,
        price: formData.price,
        published: formData.published,
        instructorId: user.uid,
        instructorName: formData.instructorName || user.displayName || 'Anonymous Instructor',
      };

      await courseService.createCourse(courseData);
      navigate('/dashboard');
    } catch (err) {
      setError('Failed to transmit course data to the central vault.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0F1115] pt-32 pb-24 px-6 relative overflow-hidden">
      {/* Background Decor */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-indigo-600/5 blur-[120px] rounded-full pointer-events-none"></div>
      
      <div className="max-w-4xl mx-auto">
        <header className="mb-12 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <button 
              onClick={() => navigate('/dashboard')}
              className="p-3 bg-[#1A1D23] border border-[#2D333B] rounded-2xl text-[#64748B] hover:text-white transition-all group"
            >
              <ChevronLeft size={20} className="group-hover:-translate-x-1 transition-transform" />
            </button>
            <div>
              <div className="text-[10px] font-black text-indigo-400 uppercase tracking-[4px] mb-2">Editor Mode</div>
              <h1 className="text-4xl font-black text-white tracking-tighter">Provision <span className="text-indigo-500">Resource</span></h1>
            </div>
          </div>
          <button 
            type="submit" 
            form="course-form"
            disabled={isLoading}
            className="px-8 py-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl font-black shadow-xl shadow-indigo-600/30 transition-all uppercase tracking-widest text-xs flex items-center gap-3 disabled:opacity-50"
          >
            {isLoading ? (
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
            ) : (
              <Save size={18} />
            )}
            Transmit Data
          </button>
        </header>

        <form id="course-form" onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Controls */}
          <div className="lg:col-span-2 space-y-8">
            <div className="bg-[#1A1D23] border border-[#2D333B] rounded-[32px] p-8 shadow-2xl">
              <h3 className="text-white font-bold mb-8 flex items-center gap-3 uppercase text-xs tracking-widest">
                <Type size={16} className="text-indigo-500" /> General Specifications
              </h3>
              
              <div className="space-y-6">
                <div>
                  <label className="block text-[10px] font-black text-[#64748B] uppercase tracking-[2px] mb-3 ml-1">Stream Title</label>
                  <input 
                    name="title"
                    value={formData.title}
                    onChange={handleChange}
                    placeholder="Enter Resource Name..."
                    className="w-full bg-[#0F1115] border border-[#2D333B] rounded-2xl px-6 py-4 text-white placeholder-[#4A5565] focus:outline-none focus:border-indigo-500/50 transition-all font-bold"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-black text-[#64748B] uppercase tracking-[2px] mb-3 ml-1">Manifest Description</label>
                  <div className="quill-dark-wrapper">
                    <ReactQuill 
                      theme="snow"
                      value={formData.description}
                      onChange={(content) => setFormData(prev => ({ ...prev, description: content }))}
                      placeholder="Document technical specifications and overview..."
                      className="bg-[#0F1115] border border-[#2D333B] rounded-2xl overflow-hidden text-white"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-[#1A1D23] border border-[#2D333B] rounded-[32px] p-8 shadow-2xl">
              <h3 className="text-white font-bold mb-8 flex items-center gap-3 uppercase text-xs tracking-widest">
                 <ImageIcon size={16} className="text-indigo-500" /> Visual Localization
              </h3>
              
              <div>
                <label className="block text-[10px] font-black text-[#64748B] uppercase tracking-[2px] mb-3 ml-1">Thumbnail URL</label>
                <div className="flex gap-4">
                  <input 
                    name="thumbnail"
                    value={formData.thumbnail}
                    onChange={handleChange}
                    placeholder="https://images.unsplash.com/..."
                    className="flex-grow bg-[#0F1115] border border-[#2D333B] rounded-2xl px-6 py-4 text-white placeholder-[#4A5565] focus:outline-none focus:border-indigo-500/50 transition-all font-mono text-sm"
                  />
                </div>
                {formData.thumbnail && (
                  <div className="mt-6 rounded-2xl overflow-hidden border border-[#2D333B] aspect-video relative group">
                    <img src={formData.thumbnail} alt="Preview" className="w-full h-full object-cover opacity-60 group-hover:opacity-100 transition-opacity" />
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40">
                       <span className="text-[10px] font-black text-white uppercase tracking-[4px]">Preview Active</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Configuration Sidebar */}
          <div className="space-y-8">
            <div className="bg-[#1A1D23] border border-[#2D333B] rounded-[32px] p-8 shadow-2xl">
               <h3 className="text-white font-bold mb-8 flex items-center gap-3 uppercase text-xs tracking-widest">
                 <Tag size={16} className="text-indigo-500" /> Classification
               </h3>
               
               <div className="space-y-8">
                 <div>
                    <label className="block text-[10px] font-black text-[#64748B] uppercase tracking-[2px] mb-3 ml-1">Sector</label>
                    <select 
                      name="category"
                      value={formData.category}
                      onChange={handleChange}
                      className="w-full bg-[#0F1115] border border-[#2D333B] rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-indigo-500/50 transition-all font-bold appearance-none cursor-pointer"
                    >
                      <option value="">Select Domain...</option>
                      <option value="Development">Neural Networks</option>
                      <option value="Design">Visual Systems</option>
                      <option value="Business">Market Intelligence</option>
                      <option value="Data Science">Quantum Data</option>
                    </select>
                 </div>

                 <div>
                    <label className="block text-[10px] font-black text-[#64748B] uppercase tracking-[2px] mb-3 ml-1">Credits Required</label>
                    <div className="relative">
                      <div className="absolute left-6 top-1/2 -translate-y-1/2 text-emerald-500">
                        <DollarSign size={18} />
                      </div>
                      <input 
                        type="number"
                        name="price"
                        value={formData.price}
                        onChange={handleChange}
                        className="w-full bg-[#0F1115] border border-[#2D333B] rounded-2xl pl-12 pr-6 py-4 text-white focus:outline-none focus:border-indigo-500/50 transition-all font-mono font-bold"
                      />
                    </div>
                 </div>

                 <div className="p-4 bg-[#0F1115] border border-[#2D333B] rounded-2xl flex items-center justify-between">
                    <span className="text-[10px] font-black text-[#64748B] uppercase tracking-[2px]">Public Stream</span>
                    <button 
                      type="button"
                      onClick={() => setFormData(prev => ({ ...prev, published: !prev.published }))}
                      className={`w-12 h-6 rounded-full transition-all relative ${formData.published ? 'bg-emerald-500' : 'bg-[#1A1D23]'}`}
                    >
                      <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${formData.published ? 'left-7' : 'left-1'}`}></div>
                    </button>
                 </div>
               </div>
            </div>

            <div className="bg-[#1A1D23] border border-[#2D333B] rounded-[32px] p-8 shadow-2xl">
               <h3 className="text-white font-bold mb-6 flex items-center gap-3 uppercase text-xs tracking-widest">
                  <UserIcon size={16} className="text-indigo-500" /> Submitter Information
               </h3>
               <div className="space-y-6">
                 <div>
                    <label className="block text-[10px] font-black text-[#64748B] uppercase tracking-[2px] mb-3 ml-1">Displayed Instructor Name</label>
                    <input 
                      name="instructorName"
                      value={formData.instructorName}
                      onChange={handleChange}
                      placeholder="Your Name..."
                      className="w-full bg-[#0F1115] border border-[#2D333B] rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-indigo-500/50 transition-all font-bold text-xs"
                    />
                 </div>
                 <div className="flex items-center gap-4 p-2">
                    <img src={user.photoURL || ''} alt="" className="w-10 h-10 rounded-xl border border-[#2D333B]" />
                    <div>
                      <div className="text-xs font-bold text-white leading-none mb-1">{user.displayName}</div>
                      <div className="text-[10px] text-[#64748B] font-medium uppercase tracking-widest">Verified Origin</div>
                    </div>
                 </div>
               </div>
            </div>

            {error && (
              <div className="p-6 bg-rose-500/10 border border-rose-500/20 rounded-[28px] text-rose-500 text-[10px] font-black uppercase tracking-[2px] leading-relaxed text-center">
                 System Error: {error}
              </div>
            )}
          </div>
        </form>
      </div>
    </div>
  );
};

export default AdminCourseForm;
