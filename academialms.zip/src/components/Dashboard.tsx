import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { courseService } from '../services/courseService';
import { Course, Enrollment, UserRole } from '../types';
import CourseCard from './CourseCard';
import { LayoutDashboard, BookOpen, Clock, Award, ChevronRight, Settings, Plus, Play, Sparkles, ShieldCheck } from 'lucide-react';
import { motion } from 'motion/react';
import { db } from '../lib/firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';

const Dashboard = () => {
  const { user, profile, setRole } = useAuth();
  const [enrollments, setEnrollments] = useState<Enrollment[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      const fetchData = async () => {
        const userEnrollments = await courseService.getUserEnrollments(user.uid);
        setEnrollments(userEnrollments);
        
        // Fetch full course data for enrolled courses
        const enrolledCourses = await Promise.all(
          userEnrollments.map(e => courseService.getCourseById(e.courseId))
        );
        setCourses(enrolledCourses.filter(c => c !== null) as Course[]);
        setLoading(false);
      };
      fetchData();
    }
  }, [user]);

  const handleSeedData = async () => {
    if (!user) return;
    
    const initialCourses = [
      {
        title: "Mastering React & Framer Motion",
        description: "Learn to build high-performance, interactive user interfaces with React and the powerful Framer Motion library.",
        thumbnail: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?q=80&w=2070&auto=format&fit=crop",
        category: "Web Development",
        instructorId: user.uid,
        instructorName: user.displayName || "Admin",
        price: 49.99,
        published: true
      },
      {
        title: "Typography for Brand Designers",
        description: "Master the art of selecting and pairing typefaces that convey professional brand identity.",
        thumbnail: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?q=80&w=2070&auto=format&fit=crop",
        category: "Design",
        instructorId: user.uid,
        instructorName: user.displayName || "Admin",
        price: 29.99,
        published: true
      }
    ];

    for (const c of initialCourses) {
      const courseId = await courseService.createCourse(c as any);
      // Add a couple of dummy lessons
      const lessonsPath = `courses/${courseId}/lessons`;
      await addDoc(collection(db, lessonsPath), {
        title: "Introduction",
        content: "Welcome to the course!",
        order: 1,
        duration: "05:00"
      });
      await addDoc(collection(db, lessonsPath), {
        title: "Setting up the environment",
        content: "Let's get started.",
        order: 2,
        duration: "12:30"
      });
    }
    alert("Sample data seeded! Refresh the page.");
  };

  const toggleInstructor = () => {
    const newRole = profile?.role === UserRole.INSTRUCTOR ? UserRole.STUDENT : UserRole.INSTRUCTOR;
    setRole(newRole);
  };

  if (!user) return <div className="py-64 text-center">Please sign in to view your dashboard.</div>;

  return (
    <div className="bg-[#0F1115] min-h-screen pt-32 pb-24 px-6">
      <div className="max-w-7xl mx-auto flex flex-col lg:flex-row gap-12">
        {/* Sidebar */}
        <aside className="lg:w-72 flex-shrink-0">
          <div className="bg-[#1A1D23] rounded-3xl shadow-2xl border border-[#2D333B] p-8 flex flex-col gap-4 sticky top-32">
            <div className="flex items-center gap-4 mb-8">
               <img src={user.photoURL || ''} alt="User" className="w-12 h-12 rounded-xl border border-[#2D333B]" />
               <div>
                  <div className="text-white font-black tracking-tight">{user.displayName}</div>
                  <div className="text-[10px] text-indigo-400 font-bold uppercase tracking-[3px]">{profile?.role}</div>
               </div>
            </div>
            
            <button className="flex items-center gap-4 p-4 bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 rounded-2xl font-bold transition-all text-sm uppercase tracking-widest">
              <LayoutDashboard size={20} /> Dashboard
            </button>
            <button className="flex items-center gap-4 p-4 text-[#64748B] hover:text-[#94A3B8] hover:bg-[#2D333B] rounded-2xl font-bold transition-all text-sm uppercase tracking-widest">
              <BookOpen size={20} /> Vault
            </button>
            <button className="flex items-center gap-4 p-4 text-[#64748B] hover:text-[#94A3B8] hover:bg-[#2D333B] rounded-2xl font-bold transition-all text-sm uppercase tracking-widest">
              <Award size={20} /> Certs
            </button>
            
            <div className="h-[1px] bg-[#2D333B] my-6"></div>
            
            <button onClick={toggleInstructor} className="flex items-center gap-4 p-4 text-[#64748B] hover:text-white rounded-2xl font-bold transition-all text-sm uppercase tracking-widest group">
              <Sparkles size={20} className="group-hover:text-amber-500 transition-colors" /> {profile?.role === UserRole.INSTRUCTOR ? 'Student View' : 'Root Access'}
            </button>
            <button className="flex items-center gap-4 p-4 text-[#64748B] hover:text-[#94A3B8] hover:bg-[#2D333B] rounded-2xl font-bold transition-all text-sm uppercase tracking-widest">
              <Settings size={20} /> Config
            </button>

            <div className="mt-12 p-5 bg-[#0F1115] border border-[#2D333B] rounded-2xl">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                <span className="text-[10px] text-[#64748B] font-bold uppercase tracking-widest">System Health</span>
              </div>
              <div className="text-[11px] text-[#4A5565] font-mono">CPU: 08% | IO: Stable</div>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <div className="flex-grow">
          <header className="mb-16 flex flex-col md:flex-row justify-between items-end gap-8">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-500/10 border border-indigo-500/20 rounded-full text-indigo-400 text-[10px] font-bold uppercase tracking-[3px] mb-4">
                Session Active: {new Date().toLocaleTimeString()}
              </div>
              <h1 className="text-5xl font-black text-white tracking-tighter">Terminal <span className="text-indigo-500">Overview</span></h1>
              <p className="text-[#94A3B8] font-medium mt-2">Pick up right where you left off, {user.displayName}.</p>
            </div>
            {profile?.role === UserRole.INSTRUCTOR && (
              <Link to="/admin/course/new" className="px-8 py-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl font-black shadow-xl shadow-indigo-600/30 transition-all uppercase tracking-widest text-xs flex items-center gap-3">
                <Plus size={18} /> Create New Stream
              </Link>
            )}
          </header>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            {[
              { label: 'Active Streams', value: enrollments.length, icon: Play, accent: 'indigo' },
              { label: 'Modules Ready', value: '12', icon: Clock, accent: 'emerald' },
              { label: 'Cred Points', value: '450', icon: Award, accent: 'amber' },
            ].map((stat, i) => (
              <div key={i} className="bg-[#1A1D23] p-8 rounded-3xl shadow-2xl border border-[#2D333B] flex items-center gap-8 group">
                <div className={`w-16 h-16 bg-${stat.accent}-500/10 border border-${stat.accent}-500/20 text-${stat.accent}-500 flex items-center justify-center rounded-2xl group-hover:scale-110 transition-transform`}>
                  <stat.icon size={24} />
                </div>
                <div>
                  <div className="text-4xl font-black text-white tracking-tighter leading-none mb-1">{stat.value}</div>
                  <p className="text-[10px] text-[#64748B] font-black uppercase tracking-[3px]">{stat.label}</p>
                </div>
              </div>
            ))}
          </div>

          {profile?.role === UserRole.INSTRUCTOR && (
            <motion.section 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-16 p-8 bg-indigo-500/5 border border-indigo-500/20 rounded-[32px] relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 p-8 opacity-20">
                <ShieldCheck size={120} className="text-indigo-500" />
              </div>
              <div className="relative z-10">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-600/30">
                     <Settings size={20} />
                  </div>
                  <h2 className="text-2xl font-black text-white tracking-tight uppercase">Root Level Controls</h2>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                   <div className="bg-[#1A1D23] p-6 rounded-2xl border border-[#2D333B]">
                      <div className="text-[10px] text-[#64748B] font-black uppercase tracking-[3px] mb-2">Network Load</div>
                      <div className="text-2xl font-bold text-white font-mono">1.2 TB / Day</div>
                   </div>
                   <div className="bg-[#1A1D23] p-6 rounded-2xl border border-[#2D333B]">
                      <div className="text-[10px] text-[#64748B] font-black uppercase tracking-[3px] mb-2">Total Queries</div>
                      <div className="text-2xl font-bold text-white font-mono">142,092</div>
                   </div>
                   <div className="bg-[#1A1D23] p-6 rounded-2xl border border-[#2D333B]">
                      <div className="text-[10px] text-[#64748B] font-black uppercase tracking-[3px] mb-2">Active Sessions</div>
                      <div className="text-2xl font-bold text-emerald-400 font-mono">829 Active</div>
                   </div>
                   <Link to="/admin/course/new" className="bg-indigo-600 border border-indigo-400/50 hover:bg-indigo-500 text-white p-6 rounded-2xl transition-all shadow-xl shadow-indigo-600/20 flex flex-col items-center justify-center gap-2 group text-center">
                      <Plus size={24} className="group-hover:rotate-90 transition-transform" />
                      <span className="text-[10px] font-black uppercase tracking-widest text-white">Create New Stream</span>
                   </Link>
                </div>
              </div>
            </motion.section>
          )}

          <section>
            <div className="flex justify-between items-end mb-12">
              <h2 className="text-3xl font-black text-white tracking-tight">Resource Catalog</h2>
              <button className="text-xs font-black text-indigo-400 hover:text-indigo-300 transition-colors uppercase tracking-[3px] flex items-center gap-2">Expand Vault <ChevronRight size={14} /></button>
            </div>

            {loading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                <div className="h-64 bg-[#1A1D23] animate-pulse rounded-3xl border border-[#2D333B]"></div>
                <div className="h-64 bg-[#1A1D23] animate-pulse rounded-3xl border border-[#2D333B]"></div>
              </div>
            ) : courses.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                {courses.map(course => (
                  <div key={course.id} className="bg-[#1A1D23] border border-[#2D333B] rounded-3xl overflow-hidden shadow-2xl flex flex-col md:flex-row group transition-all">
                    <div className="md:w-52 h-52 md:h-auto bg-[#0F1115] flex-shrink-0 relative overflow-hidden">
                       <img src={course.thumbnail} alt="" className="w-full h-full object-cover opacity-60 transition-opacity group-hover:opacity-100" />
                       <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-all flex items-center justify-center">
                          <div className="w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-2xl shadow-indigo-600/50">
                            <Play size={20} fill="currentColor" />
                          </div>
                       </div>
                    </div>
                    <div className="p-8 flex flex-col justify-between flex-grow">
                      <div>
                        <span className="text-[10px] font-black uppercase tracking-[3px] text-indigo-400 mb-3 block">{course.category}</span>
                        <h3 className="text-xl font-bold mb-4 text-white group-hover:text-indigo-400 transition-colors tracking-tight leading-tight">{course.title}</h3>
                        <div className="w-full bg-[#0F1115] h-2 rounded-full mt-6 flex overflow-hidden border border-[#2D333B]">
                           <div className="bg-indigo-500 shadow-[0_0_8px_rgba(99,102,241,0.5)]" style={{ width: '35%' }}></div>
                        </div>
                        <p className="text-[10px] text-[#64748B] font-bold mt-3 uppercase tracking-widest">35% Synchronized</p>
                      </div>
                      <button className="mt-8 text-[10px] font-black uppercase tracking-[3px] flex items-center gap-2 text-white hover:text-indigo-400 transition-all">
                        Resume Stream <ChevronRight size={16} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="py-24 bg-[#1A1D23] border border-[#2D333B] border-dashed rounded-3xl text-center">
                <div className="w-20 h-20 bg-[#0F1115] rounded-3xl flex items-center justify-center mx-auto mb-8 border border-[#2D333B] text-[#64748B]">
                  <BookOpen size={36} />
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">Vault Empty</h3>
                <p className="text-[#64748B] font-medium text-sm mb-10 max-w-sm mx-auto">No resources have been localized to your account. Query the catalog to begin.</p>
                <div className="flex gap-4 justify-center">
                   <Link to="/courses" className="px-10 py-4 bg-indigo-600 text-white font-black rounded-2xl hover:bg-indigo-500 transition-all shadow-xl shadow-indigo-600/30 uppercase tracking-widest text-xs">Access Catalog</Link>
                </div>
              </div>
            )}
          </section>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
