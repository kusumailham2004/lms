import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { LogIn, LogOut, BookOpen, LayoutDashboard, Search, PlusCircle, GraduationCap, ChevronRight, User as UserIcon } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { loginWithGoogle, logout } from './lib/firebase';

// Components
import CourseListing from './components/CourseListing';
import CourseDetail from './components/CourseDetail';
import Dashboard from './components/Dashboard';
import CoursePlayer from './components/CoursePlayer';
import LoginPage from './components/LoginPage';
import AdminCourseForm from './components/AdminCourseForm';

// Pages
const LandingPage = () => {
  return (
    <div className="min-h-screen bg-[#0F1115]">
      <section className="relative h-[650px] flex items-center justify-center overflow-hidden bg-[#0F1115] text-[#E2E8F0]">
        <div className="absolute inset-0 opacity-10 bg-[url('https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=2070&auto=format&fit=crop')] bg-cover bg-center"></div>
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#0F1115]"></div>
        <div className="relative z-10 text-center px-4 max-w-4xl">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="mb-8 inline-flex items-center gap-2 px-3 py-1 bg-indigo-500/10 border border-indigo-500/20 rounded-full text-indigo-400 text-xs font-bold uppercase tracking-widest"
          >
            <span className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse"></span>
            On-Premise Ready LMS
          </motion.div>
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl md:text-8xl font-black mb-6 tracking-tighter"
          >
            Master the <span className="text-white">Future</span> of <span className="text-indigo-500">Code</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-lg text-[#94A3B8] mb-10 max-w-2xl mx-auto font-medium"
          >
            A high-performance Learning Management System deployed on your private infrastructure. Secure, fast, and remarkably elegant.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <Link to="/courses" className="px-10 py-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl font-bold transition-all text-lg shadow-xl shadow-indigo-500/20">
              Browse Catalog
            </Link>
            <button className="px-10 py-4 bg-[#1A1D23] border border-[#2D333B] hover:bg-[#2D333B] text-white rounded-2xl font-bold transition-all text-lg">
              View Documentation
            </button>
          </motion.div>
        </div>
      </section>

      <section className="py-24 px-6 max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-baseline mb-16 gap-4">
          <div>
            <h2 className="text-4xl font-bold mb-2 text-white">Popular Streams</h2>
            <p className="text-[#94A3B8]">Professional paths curated for modern server environments</p>
          </div>
          <Link to="/courses" className="text-indigo-400 font-bold hover:text-indigo-300 flex items-center gap-2">View all catalog <ChevronRight size={16} /></Link>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {[
            { id: 1, title: 'Advanced NestJS Architecture', instructor: 'Nadim Chowdhury', price: 0, cat: 'Backend', img: 'https://images.unsplash.com/photo-1587620962725-abab7fe55159?q=80&w=2062&auto=format&fit=crop' },
            { id: 2, title: 'Server Management with Ubuntu 22', instructor: 'System Admin', price: 0, cat: 'Infrastructure', img: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc51?q=80&w=2000&auto=format&fit=crop' },
            { id: 3, title: 'Enterprise React Systems', instructor: 'Lead Dev', price: 0, cat: 'Frontend', img: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=2015&auto=format&fit=crop' },
          ].map((course) => (
            <motion.div 
              key={course.id}
              whileHover={{ y: -5 }}
              className="bg-[#1A1D23] border border-[#2D333B] rounded-3xl overflow-hidden shadow-2xl transition-all h-full flex flex-col group"
            >
              <div className="h-52 overflow-hidden relative">
                 <img src={course.img} alt="Course" className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 opacity-60 group-hover:opacity-100" />
                 <div className="absolute top-4 left-4">
                    <span className="px-3 py-1 bg-black/50 backdrop-blur-md border border-white/10 text-white text-[10px] font-bold rounded-full uppercase tracking-widest">{course.cat}</span>
                 </div>
              </div>
              <div className="p-8 flex-grow flex flex-col">
                <h3 className="text-xl font-bold mb-3 text-white group-hover:text-indigo-400 transition-colors">{course.title}</h3>
                <p className="text-[#94A3B8] text-sm mb-8 line-clamp-2 leading-relaxed">Enterprise-grade curriculum designed for on-premise deployment environments.</p>
                <div className="mt-auto pt-6 border-t border-[#2D333B] flex justify-between items-center">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-indigo-500/20 flex items-center justify-center text-indigo-400 border border-indigo-500/30">
                      <UserIcon size={16} />
                    </div>
                    <span className="text-xs font-bold text-[#E2E8F0]">{course.instructor}</span>
                  </div>
                  <span className="text-xs font-black px-3 py-1 bg-emerald-500/10 text-emerald-400 rounded-md uppercase tracking-wider">Free Early Access</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
};

const Navbar = () => {
  const { user, profile, loading } = useAuth();
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${isScrolled ? 'bg-[#0F1115]/80 backdrop-blur-xl border-b border-[#2D333B] py-4' : 'bg-transparent py-8'}`}>
      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
        <Link to="/" className="flex items-center gap-3 group">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center font-black text-white shadow-lg shadow-indigo-600/30 group-hover:rotate-6 transition-transform">L</div>
          <span className="text-2xl font-black italic tracking-tighter text-white">Lumina<span className="text-indigo-500">LMS</span></span>
        </Link>
        
        <div className="hidden md:flex items-center gap-10 font-bold text-sm tracking-wide uppercase">
          <Link to="/courses" className="text-[#94A3B8] hover:text-white transition-colors">Courses</Link>
          <Link to="/dashboard" className="text-[#94A3B8] hover:text-white transition-colors">Dashboard</Link>
          <div className="w-[1px] h-4 bg-[#2D333B]"></div>
          
          {loading ? (
             <div className="w-8 h-8 rounded-xl bg-[#1A1D23] animate-pulse"></div>
          ) : user ? (
            <div className="flex items-center gap-6">
               <Link to="/dashboard" className="flex items-center gap-3 group">
                 <div className="text-right">
                   <div className="text-xs text-white leading-none mb-1">{user.displayName}</div>
                   <div className="text-[10px] text-[#64748B] font-bold tracking-widest">{profile?.role}</div>
                 </div>
                 <img src={user.photoURL || ''} alt="User" className="w-10 h-10 rounded-xl border border-[#2D333B] group-hover:border-indigo-500 transition-colors" />
               </Link>
               <button onClick={logout} className="p-2.5 bg-[#1A1D23] hover:bg-rose-500/10 text-[#64748B] hover:text-rose-500 rounded-xl border border-[#2D333B] transition-all">
                 <LogOut className="w-4 h-4" />
               </button>
            </div>
          ) : (
            <Link 
              to="/login"
              className="flex items-center gap-2 px-8 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-500 transition-all shadow-lg shadow-indigo-600/20"
            >
              <LogIn className="w-4 h-4" /> Sign In
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
};

const Layout = ({ children }: { children: React.ReactNode }) => {
  return (
    <div className="bg-[#0F1115]">
      <Navbar />
      <main>{children}</main>
      <footer className="bg-[#1A1D23] text-[#E2E8F0] py-20 px-6 border-t border-[#2D333B]">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-16">
          <div className="col-span-1 md:col-span-1">
            <div className="flex items-center gap-3 mb-8">
              <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center font-bold text-white">L</div>
              <span className="text-xl font-black italic tracking-tighter text-white">Lumina<span className="text-indigo-500">LMS</span></span>
            </div>
            <p className="text-[#94A3B8] text-sm leading-relaxed mb-6">
              A professional Learning Management System designed for enterprise scale and secure on-premise operations.
            </p>
            <div className="flex gap-4">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
              <span className="text-[10px] uppercase font-bold tracking-[3px] text-[#64748B]">Instance: Healthy</span>
            </div>
          </div>
          <div>
            <h4 className="font-bold mb-8 uppercase text-[10px] tracking-[4px] text-[#64748B]">Learning Paths</h4>
            <ul className="space-y-4 text-sm text-[#94A3B8]">
              <li><Link to="/courses" className="hover:text-white transition-colors">Catalog Mastery</Link></li>
              <li><Link to="/" className="hover:text-white transition-colors">Infrastructure Guides</Link></li>
              <li><Link to="/" className="hover:text-white transition-colors">API Architecture</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-8 uppercase text-[10px] tracking-[4px] text-[#64748B]">System</h4>
            <ul className="space-y-4 text-sm text-[#94A3B8]">
              <li><Link to="/login?type=instructor" className="hover:text-white transition-colors">Instructor Portal</Link></li>
              <li><Link to="/" className="hover:text-white transition-colors">Server Stats</Link></li>
              <li><Link to="/" className="hover:text-white transition-colors">Security Audit</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-8 uppercase text-[10px] tracking-[4px] text-[#64748B]">Terminal Access</h4>
            <p className="text-sm text-[#94A3B8] mb-6 font-mono">Join our developers newsletter for system updates.</p>
            <div className="flex bg-[#0F1115] border border-[#2D333B] rounded-xl p-1 shadow-inner">
              <input type="email" placeholder="Email.." className="bg-transparent border-none px-4 py-2 text-xs focus:ring-0 flex-grow text-white font-mono" />
              <button className="bg-indigo-600 px-4 py-2 rounded-lg font-bold text-[10px] uppercase tracking-widest text-white shadow-lg">Submit</button>
            </div>
          </div>
        </div>
        <div className="max-w-7xl mx-auto border-t border-[#2D333B] mt-20 pt-10 text-center text-[#64748B] text-[10px] font-bold uppercase tracking-[2px]">
          &copy; 2026 LuminaLMS | Running on Ubuntu 22.04 LTS
        </div>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <Router>
      <AuthProvider>
        <Layout>
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/courses" element={<CourseListing />} />
            <Route path="/course/:id" element={<CourseDetail />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/admin/course/new" element={<AdminCourseForm />} />
            <Route path="/learning/:id" element={<CoursePlayer />} />
          </Routes>
        </Layout>
      </AuthProvider>
    </Router>
  );
}


