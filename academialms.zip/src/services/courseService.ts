import { 
  collection, 
  getDocs, 
  getDoc, 
  doc, 
  addDoc, 
  updateDoc, 
  query, 
  where, 
  serverTimestamp,
  orderBy
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Course, Lesson, Enrollment, OperationType } from '../types';
import { handleFirestoreError } from '../lib/utils';

const COURSES_COLLECTION = 'courses';
const ENROLLMENTS_COLLECTION = 'enrollments';

export const courseService = {
  async getAllCourses(): Promise<Course[]> {
    try {
      const q = query(collection(db, COURSES_COLLECTION), where('published', '==', true), orderBy('createdAt', 'desc'));
      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Course));
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, COURSES_COLLECTION);
      return [];
    }
  },

  async getCourseById(id: string): Promise<Course | null> {
    try {
      const docRef = doc(db, COURSES_COLLECTION, id);
      const snapshot = await getDoc(docRef);
      if (snapshot.exists()) {
        return { id: snapshot.id, ...snapshot.data() } as Course;
      }
      return null;
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, `${COURSES_COLLECTION}/${id}`);
      return null;
    }
  },

  async getLessons(courseId: string): Promise<Lesson[]> {
    const path = `${COURSES_COLLECTION}/${courseId}/lessons`;
    try {
      const q = query(collection(db, path), orderBy('order', 'asc'));
      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Lesson));
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, path);
      return [];
    }
  },

  async createCourse(courseData: Partial<Course>): Promise<string> {
    try {
      const docRef = await addDoc(collection(db, COURSES_COLLECTION), {
        ...courseData,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      return docRef.id;
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, COURSES_COLLECTION);
      throw error;
    }
  },

  async enrollInCourse(userId: string, courseId: string): Promise<void> {
    try {
      await addDoc(collection(db, ENROLLMENTS_COLLECTION), {
        userId,
        courseId,
        enrolledAt: serverTimestamp(),
        progress: 0,
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, ENROLLMENTS_COLLECTION);
    }
  },

  async getUserEnrollments(userId: string): Promise<Enrollment[]> {
    try {
      const q = query(collection(db, ENROLLMENTS_COLLECTION), where('userId', '==', userId));
      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Enrollment));
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, ENROLLMENTS_COLLECTION);
      return [];
    }
  }
};
